<?php 
  $a = $_GET["a"];
  echo '{"id":"'.$a.'","name" : "张三","age":15}';
?>